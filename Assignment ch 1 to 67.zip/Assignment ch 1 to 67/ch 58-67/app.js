var a = document.getElementById('main-content')
var b = a.getElementsByTagName('p')
console.log(b)

var a = document.getElementById('main-content')
console.log(a.childNodes)

var a = document.getElementsByClassName('render')[0]
var c = document.getElementsByClassName('render')[1]
var e = document.getElementsByClassName('render')[2]
var g = document.getElementsByClassName('render')[3]
var i = document.getElementsByClassName('render')[4]
var b = a.childNodes[0]
var d = c.childNodes[0]
var f = e.childNodes[0]
var h = g.childNodes[0]
var j = i.childNodes[0]
document.write(b.nodeValue,
    d.nodeValue, f.nodeValue, h.nodeValue, j.nodeValue)

var a = document.getElementsByClassName('render')[0]
var b = a.childNodes[0].nodeValue;
document.getElementById("first-name").value = b;


var a = document.getElementsByClassName('render')[1]
var b = a.childNodes[0].nodeValue;
document.getElementById("last-name").value = b;


var a = document.getElementsByClassName('render')[2]
var b = a.childNodes[0].nodeValue;
document.getElementById("email").value = b;


var a = document.getElementById('form-content')
var b = a.nodeType

if (b == 1) {
    console.log(b + ' Element')
} else if (b == 2) {
    console.log(b + ' Attrib')
} else {
    console.log(b + ' Text')
}


var a = document.getElementById('lastName')
console.log(a.nodeType)
console.log(a.childNodes[0])


var textnode = document.createTextNode('Last Name: Riley');
var a = document.getElementById('lastName')
var b = a.replaceChild(textnode, a.childNodes[0])

var a = document.getElementById('main-content')
console.log(a.firstChild)
console.log(a.lastChild)


var a = document.getElementById('lastName')
console.log(a.nextSibling)
console.log(a.previousSibling)


var a = document.getElementById('email')
console.log(a.parentNode)
console.log(a.nodeType)