//Task # 1

// function submit() {
//     var name = document.getElementById('name').value;
//     var email = document.getElementById('email').value;
//     var pass = document.getElementById('pass').value;
//     document.write('Name: ' + name + '<br>')
//     document.write('Email: ' + email + '<br>')
//     document.write('Password: ' + pass)
// }


//Task # 2

// function readmore() {
//     var para;
//     para = document.getElementById('para').innerHTML = 'USP of the Xiaomi Mi A3 is the 32MP AI selfie camera which comes with features like Portrait mode, scene detection and palm shutter. Other camera specs include the triple lens setup at the back. This comprises of a 48MP primary camera with Sony IMX586 sensor having an aperture of f/1.79.'

// }


//Task # 3
function submit() {
    var name = document.getElementById('name').value;
    var clas = document.getElementById('class').value;
    var roll = document.getElementById('roll').value;
    document.getElementsByTagName('td').innerHTML = name;
    document.getElementsByTagName('td').innerHTML = clas;
    document.getElementsByTagName('td').innerHTML = roll;
}


// function delRow() {
//     var current = window.event.srcElement;
//     //here we will delete the line
//     while ((current = current.parentElement) && current.tagName != "TR");
//     current.parentElement.removeChild(current);
// }