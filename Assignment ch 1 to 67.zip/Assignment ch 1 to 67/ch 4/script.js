//Task # 1

var variable1 = "Hello World!",
    variable2 = "Testing...",
    variable3 = 42;

document.write(variable1 + variable2 + variable3);

//Task # 2

//Legal Variable
var name;
var birthYear;
var $year;
var name_of_student;
var std123;

//Illegal Variable
// var 1stnumber;
// var my name;
// var @year;
// var while;
// var for;



//Task # 3

// a) A heading stating “Rules for naming JS variables”
// b) Variable names can only contain ______, ______, ______ and ______.For example $my_1stVariable
// c) Variables must begin with a ______, ______ or _____. For example $name, _name or name
// d) Variable names are case _________
// e) Variable names should not be JS _________
document.write("<h1>" + "Rules for naming JS variables" + "</h1>");
document.write("Variable names can only contain numbers, $ and _. For example: $my_1stVariable." + "<br/>");
document.write("Variable must begin with a letter, $ or _. For example: $name, _name or name" + "<br/>");
document.write(" Variable names are case sensitive" + "<br/>");
document.write("Variable names should not be JS keywords" + "<br/>");