// Task # 1

var city = prompt('Enter your City Name').toUpperCase();
if (city == 'KARACHI') {
    alert('Welcome to the city of lights')
} else {
    alert('Welcome to the City')
}

// Task # 2


var gender = prompt('Enter your Gender').toLowerCase();
if (gender == 'male') {
    alert('Welcome Sir')
} else if (gender == 'female') {
    alert('Welcome Mam')
} else {
    alert('Please Enter Correct Gender')
}


// Task # 3


var color = prompt('Enter Color Name').toLowerCase();
if (color == 'red') {
    alert('Must Stop')
} else if (color == 'yellow') {
    alert('Ready to move')
} else if (color == 'green') {
    alert('Move Now')
} else {
    alert('Please Enter Correct Color Name')

}

// Task # 4


var fuel = parseFloat(prompt('Enter Fuel'))
var a = fuel / 100
if (a < 0.25) {
    alert('Please refill the fuel in your car')
} else {
    alert('Enjoy')
}


// Task # 5

var a = 4;
if (++a === 5) {
    alert("given condition for variable a is true");
}

var b = 82;
if (b++ === 83) {
    alert("given condition for variable b is true");
}
var c = 12;
if (c++ === 13) {
    alert("condition 1 is true");
}
if (c === 13) {
    alert("condition 2 is true");
}
if (++c < 14) {
    alert("condition 3 is true");
}
if (c === 14) {
    alert("condition 4 is true");
}
var materialCost = 20000;
var laborCost = 2000;
var totalCost = materialCost + laborCost;
if (totalCost === laborCost + materialCost) {
    alert("The cost equals");
}
if (true) {
    alert("True");
}
if (false) {
    alert("False");
}

if ("car" < "cat") {
    alert("car is smaller than cat");
}

// Task # 6


var total = parseInt(prompt('Enter Total Marks'))
var obt = parseInt(prompt('Enter Obtained Marks'))
var percen = (obt / total) * 100

document.write('Total Marks: ' + total + '<br>')
document.write('Obtained Marks: ' + obt + '<br>')
document.write('Percentage: ' + percen + '%' + '<br>')
if (percen >= 80) {
    document.write('Grade: A-one' + '<br>')
    document.write('Remarks: Excellent' + '<br>')
} else if (percen >= 70) {
    document.write('Grade: A' + '<br>')
    document.write('Remarks: Good' + '<br>')
} else if (percen >= 60) {
    document.write('Grade: B' + '<br>')
    document.write('Remarks: You Need to improve' + '<br>')
} else {
    document.write('Grade: Fail' + '<br>')
    document.write('Remarks: Sorry' + '<br>')
}

// Task # 7

var guess = parseInt(prompt('Enter Value 1 to 10'))

if (guess == 3 || guess == 6 || guess == 9) {
    alert('Bingo! Correct Answer')
} else if (guess == 4 || guess == 7 || guess == 10) {
    alert('Close enough to the correct answer')
} else {
    alert('Try Again')
}


// Task # 8

var num = parseInt(prompt('Enter Number'))
if (num % 3 == 0) {
    alert('The Number is divisible by 3')
} else {
    alert('The Number is Not divisible by 3')
}


// Task # 9


var num = parseInt(prompt('Enter Number'))
if (num % 2 !== 0) {
    alert(num + ' Number is Odd')
} else {
    alert(num + ' Number is not Odd')
}

// Task # 10

var temp = parseInt(prompt('Enter Temprature'))
if (temp > 40) {
    alert('It is too Hot Outside')
} else if (temp > 30) {
    alert('The Weather is today Normal')
} else if (temp > 20) {
    alert('Today Weather is Cool')
} else if (temp > 10) {
    alert('OMG! Today Weather is so cool')
}

// Task # 11

var val1 = parseInt(prompt('Enter Value 1'))
var val2 = parseInt(prompt('Enter Value 2'))
var opt = prompt('Enter Operator')

if (opt == '+') {
    alert(val1 + val2)
} else if (opt == '-') {
    alert(val1 - val2)
} else if (opt == '/') {
    alert(val1 / val2)
} else if (opt == '*') {
    alert(val1 * val2)
} else {
    alert('Please Enter Correct Operator Or Value')
}