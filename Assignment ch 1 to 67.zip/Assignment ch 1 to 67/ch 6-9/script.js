// Task # 1

var a = 10
document.write('Result a = ' + a + '<br><br>')
document.write('The Value of ++a is ' + ++a + '<br>')
document.write('Now the Value is ' + a + '<br><br><br>')

document.write('The Value of a++ is ' + a++ + '<br>')
document.write('Now the Value is ' + a + '<br><br><br>')

document.write('The Value of --a is ' + --a + '<br>')
document.write('Now the Value is ' + a + '<br><br><br>')

document.write('The Value of a-- is ' + a-- + '<br>')
document.write('Now the Value is ' + a + '<br><br><br>')

// Task # 2

var a = 2,
    b = 1

document.write('a is ' + a + '<br>')
document.write('b is ' + b + '<br>')
var result = --a - --b + ++b + b--;
document.write('result is ' + result + '<br><br><br>')
document.write(--a + '<br>')
document.write(--a - --b + '<br>')
document.write(--a - --b + ++b + '<br>')
document.write(--a - --b + ++b + b-- + '<br>')

// Task # 3


var name = prompt('Enter Your Name')
document.write('Welcome ' + name + ' in Our Page')


// Task # 4


var table = prompt('Enter Table Number')
if (table == '') {
    table = 5;
}


document.write('Table of ' + table + '<br>')

document.write(table + ' x ' + ' 1 ' + ' = ' + table * 1 + '<br>')
document.write(table + ' x ' + ' 2 ' + ' = ' + table * 2 + '<br>')
document.write(table + ' x ' + ' 3 ' + ' = ' + table * 3 + '<br>')
document.write(table + ' x ' + ' 4 ' + ' = ' + table * 4 + '<br>')
document.write(table + ' x ' + ' 5 ' + ' = ' + table * 5 + '<br>')
document.write(table + ' x ' + ' 6 ' + ' = ' + table * 6 + '<br>')
document.write(table + ' x ' + ' 7 ' + ' = ' + table * 7 + '<br>')
document.write(table + ' x ' + ' 8 ' + ' = ' + table * 8 + '<br>')
document.write(table + ' x ' + ' 9 ' + ' = ' + table * 9 + '<br>')
document.write(table + ' x ' + ' 10 ' + ' = ' + table * 10 + '<br>')

// Task # 5

var total = 100
var subname1 = prompt('Enter 1st Subjet Name')
document.getElementById('sub1').innerHTML = subname1;
var obt1 = parseInt(prompt('Enter 1st Obtained Marks'))
document.getElementById('obt1').innerHTML = obt1;
var perc1 = (obt1 / total) * 100
document.getElementById('percen1').innerHTML = perc1 + '%';

var subname2 = prompt('Enter 2nd Subjet Name')
document.getElementById('sub2').innerHTML = subname2;
var obt2 = parseInt(prompt('Enter 2nd Obtained Marks'))
document.getElementById('obt2').innerHTML = obt2;
var perc2 = (obt2 / total) * 100
document.getElementById('percen2').innerHTML = perc2 + '%';

var subname3 = prompt('Enter 3rd Subjet Name')
document.getElementById('sub3').innerHTML = subname3;
var obt3 = parseInt(prompt('Enter 3rd Obtained Marks'))
document.getElementById('obt3').innerHTML = obt3;
var perc3 = (obt3 / total) * 100
document.getElementById('percen3').innerHTML = perc3 + '%';



var total1 = obt1 + obt2 + obt3;
var totalper1 = perc1 + perc2 + perc3;
var totalmarks = document.getElementById('obt4')
totalmarks.innerHTML = total1;
var totalpercen = document.getElementById('percen4')
totalpercen.innerHTML = total1 / 300 * 100 + '%';