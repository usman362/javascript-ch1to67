//Task # 1

var age = 15
alert('I am ' + age + 'years old')

//Task # 2
var numberOfVisit = 44;
alert("You have visited this site " + numberOfVisit + " times.");


//Task # 3

var birth = 1999
document.write('My birthday year is ' + birth + '<br>' + 'Data type of my declared variable is number');

//Task # 4
alert('XYZ Clothing store')
var name = prompt('Enter Your Name')
var title = prompt('Enter Product Title')
var quantity = prompt('Enter your quantity')

document.write(name + ' ordered ' + quantity + title + ' on XYZ Clothing store')