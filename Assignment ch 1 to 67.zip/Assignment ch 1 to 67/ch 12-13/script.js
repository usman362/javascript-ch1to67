//Task # 1
var ch = prompt('Enter Value')

if (ch >= 'A' && ch <= 'Z') {
    alert("\n" + ch + " is an UpperCase character");
} else if (ch >= 'a' && ch <= 'z') {
    alert("\n" + ch + " is an LowerCase character");
} else {
    alert("\n" + ch + " is not an aplhabetic character");
}

//Task # 2

var firstNumber = +prompt("Enter First Number: ");
var secondNumber = +prompt("Enter Second Number: ");

if (firstNumber > secondNumber) {
    alert(firstNumber + " is larger than " + secondNumber);
} else if (firstNumber < secondNumber) {
    alert(secondNumber + " is larger than " + firstNumber);
} else {
    alert(firstNumber + " and " + secondNumber + " both are eqaul");
}

//Task # 3
var num = +prompt("Enter a number to check its state: ");

if (num > 0) {
    alert(num + " is Positive");
} else if (num < 0) {
    alert(num + " is Negative");
} else {
    alert("The number is " + num);
}


//Task # 4
var character = prompt("Enter character to check vowel or not");

if (character === "a" || character === "e" || character === "i" || character === "o" || character === "u") {
    alert(character + " is vowel");
} else if (character === "A" || character === "E" || character === "I" || character === "O" || character === "U") {
    alert(character + " is vowel");
} else {
    alert(character + " is not vowel");
}

//Task # 5

var password = prompt('Enter Password')
var pass = 'football'

if (check === "") {
    check = prompt("Please enter your password");
}
if (check === password) {
    alert("Correct! The password you entered matches the original password");
} else {
    alert("Incorrect Password");
}


//Task # 6

var greeting;
var hour = 13;
if (hour < 18) {
    greeting = "Good day";
    alert(greeting);
} else {
    greeting = "Good evening";
    alert(greeting);
}

//Task # 7

var time = +prompt("Please enter 24 hours clock format time \nlike: 1900 = 7pm.");

if (time >= 0000 && time < 1200) {
    alert("Good Morning");
} else if (time >= 1200 && time < 1700) {
    alert("Good Afternoon");
} else if (time >= 1700 && time < 2100) {
    alert("Good Evening");
} else if (time >= 2100 && time <= 2359) {
    alert("Good Night");
} else {
    alert("Invalid Input");
}