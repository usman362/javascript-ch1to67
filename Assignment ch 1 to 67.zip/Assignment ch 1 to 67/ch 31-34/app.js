// Task #
1
var rightNow = new Date();
var dateString = rightNow.toString();
alert(dateString)

// Task # 2


var date = new Date();
date = date.toString();
var month = date.slice(4, 8);
alert("Current Month: " + month);

// Task # 3


var date = new Date();
date = date.toString();
var day = date.slice(0, 4);
alert("Today is " + day);

alert('Today is ' + n)

// Task # 4


var day = prompt("Enter Day");
day = day.toLowerCase();
if (day === "saturday" || day === "sunday") {
    alert("It's Fun day");
} else {
    alert("It's not a Fun day");
}


// Task # 5


var date = new Array();
var day = new Date();
day = day.getDate();
if (day < 16) {
    document.write("First fifteen days of the month");
} else {
    document.write("Last days of the month");
}

// Task # 6


var rightnow = new Date();
var currentdate = rightnow.toString();
document.write('Current Date: ' + currentdate + '<br>');

var d = new Date();
var millisec = d.getTime();
document.write('Eplased Milliseconds since January 1,1970: ' + millisec + '<br>')

var f = new Date();
var millisec = f.getTime();
var min = Math.floor((millisec / 1000 / 60) << 0)
document.write('Eplased Minutes since January 1,1970: ' + min)


// Task # 7

var d = new Date();
var time = d.getHours();
if (time < 12) {
    alert('Its AM')
} else {
    alert('Its PM')
}

// Task # 8

var date = new Date();
var lastDay = new Date(date.getFullYear(), date.getMonth() + 7, 0);
document.write("<br>" + 'Later Due: ' + lastDay);


// Task # 9

var ramadan = new Date("June 18, 2015");
var ramadanMili = ramadan.getTime();
var date = new Date();
var dateMili = date.getTime();
var dif = dateMili - ramadanMili;
dif = dif / (1000 * 60 * 60 * 24);
document.write(Math.floor(dif) + " days have passed since 1st Ramadan, 2015");


// Task # 10

var begDate = new Date("Jan 01, 2018");
var begDateMili = begDate.getTime();
var refDate = new Date("Sat Dec 05, 2018 22:50:16");
document.write("On reference date " + refDate + ", <br>")
var refDateMili = refDate.getTime();
var dif = refDateMili - begDateMili;
dif = dif / (1000 * 60);
document.write(Math.ceil(dif) + " seconds has passed since beginning of 2018");


// Task # 11

var date = new Date("Jun 20, 2020 12:30:00");
document.write("current date: " + date + "<br>");
var hour = new Date("Jun 20, 2020 11:30:00");
document.write("1 hour ago, it was " + hour);


// Task # 12

var date = new Date("Jun 19, 2020 12:30:00");
document.write("current date: " + date + "<br>");
var year = new Date("Jun 19, 1920 11:30:00");
document.write("100 years back , it was " + year);


// Task # 13

var userInput = new Date(prompt("Enter Your Birth Year"));
var userInputMili = userInput.getTime();
userInput = userInput.getFullYear();
var todayDate = new Date();
var todayDateMili = todayDate.getTime();
var dif = todayDateMili - userInputMili;
dif = dif / (1000 * 60 * 60 * 24 * 30 * 12);
document.write("Your age is " + Math.floor(dif) + "<br>");
document.write("Your birth year is " + userInput);


// Task # 14

document.write("<h1>K-Electric Bill</h1> <br>");
var name = prompt("Enter your name");
document.write("Costumer Name: " + "<strong>" + name + "</strong>" + "<br>")
var month = "June";
document.write("Month: " + "<strong>" + month + "</strong>" + "<br>");
var numOfUnits = +prompt("Enter consumed units");
document.write("Number of units: " + "<strong>" + numOfUnits + "</strong>" + "<br>");
var charges = 16;
document.write("Charges per unit: " + "<strong>" + charges + "</strong>" + "<br><br>");
var netAmount = numOfUnits * charges;
document.write("Net Amount Payable (within Due Date): " + "<strong>" + netAmount + "</strong>" + "<br>");
var latePay = 350;
document.write("Late Payment Surcharge: " + "<strong>" + latePay + "</strong>" + "<br>");
var grossAmount = netAmount + latePay;
document.write("Gross Amount Payable (after Due Date): " + "<strong>" + grossAmount + "</strong>");