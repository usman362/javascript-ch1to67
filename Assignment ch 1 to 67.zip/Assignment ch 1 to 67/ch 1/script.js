// Task # 1

alert("Welcome User");


//Task # 2

alert('Error! Please Enter a Valid Password')

//Task # 3

alert('Welcome to JS Land ' + ' \n' + 'Happy Coding!')

// Task # 4

alert('Welcome to JS Land')

alert('Happy Coding!')

//Task# 5

console.log(alert('Hello...I can run JS through my web browser console'))