//Task # 1 
// function f() {
//     alert('Bingo!')
// }


//Task # 2
// function f() {
//     alert('Thank you For Purchasing with us')
// }


//Task # 3

// function delRow() {
//     var current = window.event.srcElement;
//     //here we will delete the line
//     while ((current = current.parentElement) && current.tagName != "TR");
//     current.parentElement.removeChild(current);
// }


//Task # 4

//Task # 5

// function incrementValue() {
//     var value = parseInt(document.getElementById('number').value, 10);
//     value = isNaN(value) ? 0 : value;
//     value++;
//     document.getElementById('number').value = value;
// }

// function decrementValue() {
//     var value = parseInt(document.getElementById('number').value, 10);
//     value = isNaN(value) ? 0 : value;
//     value--;
//     document.getElementById('number').value = value;
}