// Task # 1
// function sum(a, b) {
//     return a + b;
// }

// var result = sum(1, 2);
// alert(result);

//Task # 2

// function isLeapYear() {

//     var year = prompt('Enter Year')
//     var result;
//     if (result = (year % 100 === 0) ? (year % 400 === 0) :
//         (year % 4 === 0)) {
//         alert(year + ' is Leap Year')
//     } else {
//         alert(year + ' is not Leap Year')
//     }

// }

// isLeapYear();


// Task # 3
// function area() {
//     var side1 = prompt('Enter side1: ');
//     var side2 = prompt('Enter side2: ');
//     var side3 = prompt('Enter side3: ');

//     var s = (side1 + side2 + side3) / 2;


//     var areaValue = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));

//     document.write('The area of a triangle with side length ' + areaValue);
// }
// area();


//Task # 4

// function marks() {
//     var marks1 = parseInt(prompt('Enter Marks 1'))
//     var marks2 = parseInt(prompt('Enter Marks 2'))
//     var marks3 = parseInt(prompt('Enter Marks 3'))


//     var total = marks1 + marks2 + marks3;
//     alert('Your Marks ' + total + ' Out of 500');

//     function percetage() {
//         var perc = total / 5
//         alert(perc + '%')
//     }
//     percetage();
// }
// marks();


//Task # 5
// var str = prompt('Enter Word or Sentence Here')
// var n = prompt('Which Character do you Find in your sentence?')

// function find() {
//     var find = str.lastIndexOf(n)
//     alert(find)
// }
// find();

//Task # 6
// var input = prompt('Enter Sentence Or Word')
// if (input.length > 25) {
//     alert('Please Enter Minimum 25 Character')
// } else {

//     function removeVowels(str) {

//         var vowels = "aieuo";
//         var strArr = str.toLowerCase().split("");
//         var newArr = strArr.filter(function(letter) {
//             if (vowels.indexOf(letter) == -1) {
//                 return letter;
//             }
//         });
//         var string = "";
//         newArr.forEach(function(letter) {
//             string += letter;
//         });
//         return string;

//     }
//     document.write('Normal: ' + input + '<br>')
// }

// document.write('After Removing Vowels: ' + removeVowels(input));


//Task # 7

// function findOccurrences() {
//     var str = "Pleases read this application and give me gratuity";
//     var count = 0;
//     let haveSeenVowel = false;

//     for (const letter of str.toLowerCase()) {
//         switch (letter) {
//             case 'a':
//             case 'e':
//             case 'i':
//             case 'o':
//             case 'u':
//                 {
//                     if (haveSeenVowel) {
//                         count++;
//                         haveSeenVowel = false;
//                     } else {
//                         haveSeenVowel = true;
//                     }
//                     break;
//                 }
//             default:
//                 haveSeenVowel = false
//         }
//     }

//     return count
// }

// document.write(findOccurrences());

//Task # 8
// var city = prompt("Enter distance in kilometers: ");

// var m = city * 1000;
// var cm = city * 1000 * 100;
// var f = city * 3280.84;
// var inch = city * 39370.08;
// document.write("The distance in Feet: ", f + '<br>');
// document.write("The distance in Inches:", inch + '<br>');
// document.write("The distance in Meters: ", m + '<br>');
// document.write("The distance in Centimeters: ", cm + '<br>');


//Task # 9

// var overtime = 40;


// var str = parseInt(prompt("Enter the working hours of employee no: "));

// if (str > overtime) {
//     var sub = str - overtime;
//     var overtimepay = sub * 12;
//     document.write('Employee overtime pay is Rs.' + overtimepay);
// } else {
//     document.write("You have to work for more than 40 hours to get over time pay");


// }


// Task # 10

// var amount = prompt("Please Enter Amount for Withdraw :")
// var hundred = amount / 100
// var fifty = (amount % 100) / 50
// var ten = (((amount % 100) % 50) / 10)
// var remaining = (((amount % 100) % 50) % 10)
// document.write("Required notes of 100 is : " + parseInt(hundred) + '<br>')
// document.write("Required notes of 50 is : " + parseInt(fifty) + '<br>')
// document.write("Required notes of 10 is : " + parseInt(ten) + '<br>')
// document.write("amount still remaining is : " + parseInt(remaining))