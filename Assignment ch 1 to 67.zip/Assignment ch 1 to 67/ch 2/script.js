// Task # 1

var username = 'Muhammad Usman'
document.write(username)

// Task # 2

var fname = 'Muhammad Usman'
var lname = ' Muhammad Shoaib'
var fullname = fname + lname

document.write(fullname)

// Task # 3

var greet = 'Hello World'
alert(greet)

// Task # 4

var name = 'Muhammad Usman'
var age = 20
var course = 'Certified Mobile Application Development'

alert(name)
alert(age)
alert(course)

// Task # 5
var pizza = 'pizza'
var pizz = 'pizz'
var piz = 'piz'
var pi = 'pi'
var p = 'p'

alert(pizza + ' \n' + pizz + ' \n' + piz + ' \n' + pi + ' \n' + p)

// Task # 6

var email = ' example@example.com'
alert('my email address is ' + email)

// Task # 7

var book = ' A Smarter Way to learn Javascript'
alert('I am trying to learn from the Book' + book)

// Task # 8
var str = 'Yeah I can write HTML content through Javascript'
document.write(str)

// Task # 9
var str = '▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬'
alert(str)