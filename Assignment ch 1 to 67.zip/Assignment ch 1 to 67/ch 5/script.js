// Task # 1

var val1 = prompt('Enter value 1')
var val2 = prompt('Enter value 2')
var sum = parseInt(val1) + parseInt(val2);
document.write('Sum of ' + val1 + ' and ' + val2 + ' is ' + sum)

// Task # 2


var val1 = prompt('Enter value 1')
var val2 = prompt('Enter value 2')
var sub = parseInt(val1) - parseInt(val2);
var mul = parseInt(val1) * parseInt(val2);
var divs = parseInt(val1) / parseInt(val2);
document.write('Substraction of ' + val1 + ' and ' + val2 + ' is ' + sub + '<br>')
document.write('Multiplication of ' + val1 + ' and ' + val2 + ' is ' + mul + '<br>')
document.write('Division of ' + val1 + ' and ' + val2 + ' is ' + divs + '<br>')

// Task # 3


var val;
document.write('Value after declaration is ' + val + '<br>')
var val = 5
document.write('Initial value is: ' + val + '<br>')
var val1 = ++val;
document.write('Value after Increment is: ' + val1 + '<br>')
var val2 = val1 + 7
document.write('Value after addition is: ' + val2 + '<br>')
var val3 = --val2
document.write('Value after decrement is: ' + val3 + '<br>')
var val4 = val3 % 3
document.write('The Reminder is ' + val4)

// Task # 4


var ticket = 600
var quantity = parseInt(prompt('Enter your ticket quantity'))
document.write('Total cost to buy ' + quantity + ' tickets is ' + ticket * quantity)

// Task # 5


var table = parseInt(prompt('Enter Table Number'))

document.write('Table of ' + table + '<br>')

document.write(table + ' x ' + ' 1 ' + ' = ' + table * 1 + '<br>')
document.write(table + ' x ' + ' 2 ' + ' = ' + table * 2 + '<br>')
document.write(table + ' x ' + ' 3 ' + ' = ' + table * 3 + '<br>')
document.write(table + ' x ' + ' 4 ' + ' = ' + table * 4 + '<br>')
document.write(table + ' x ' + ' 5 ' + ' = ' + table * 5 + '<br>')
document.write(table + ' x ' + ' 6 ' + ' = ' + table * 6 + '<br>')
document.write(table + ' x ' + ' 7 ' + ' = ' + table * 7 + '<br>')
document.write(table + ' x ' + ' 8 ' + ' = ' + table * 8 + '<br>')
document.write(table + ' x ' + ' 9 ' + ' = ' + table * 9 + '<br>')
document.write(table + ' x ' + ' 10 ' + ' = ' + table * 10 + '<br>')


// Task # 6

//a.Store a Celsius temperature into a variable.
var celsius = 25;
//b.Convert it to Fahrenheit & output“ NNoC is NNoF”.
var fahrenheit = (celsius * 9 / 5) + 32;
//c.Now store a Fahrenheit temperature into a variable.
fahrenheit = 77;
//d.Convert it to Celsius & output“ NNoF is NNoC”.
celsius = (fahrenheit - 32) * 5 / 9;
document.write(celsius + "C is " + fahrenheit + "F" + "<br/>");
document.write(fahrenheit + "F is " + celsius + "C" + "<br/>");


document.write(celsius + ' is ' + c + '<br>')
document.write(fahrenheit + ' is ' + f + '<br>')


// Task # 7


var item1 = parseInt(prompt('Enter Price of item1'))
var quanity1 = parseInt(prompt('Enter Qunantity of item1'))
var total1 = item1 * quanity1
var item2 = parseInt(prompt('Enter Price of item2'))
var quanity2 = parseInt(prompt('Enter Qunantity of item2'))
var total2 = item2 * quanity2
var delievery = 100
var totalcost = total1 + total2 + delievery
document.write('Price of Item1 is: ' + item1 + '<br>')
document.write('Quantity of Item1 is: ' + quanity1 + '<br>')
document.write('Price of Item2 is: ' + item2 + '<br>')
document.write('Quantity of Item2 is: ' + quanity2 + '<br>')
document.write('Delievery Charges is: ' + delievery + '<br><br>')

document.write('Total total cost of your Order is: ' + totalcost)

// Task # 8


var total = parseInt(prompt('Enter Total Marks'))
var obt = parseInt(prompt('Enter Obtained Marks'))
var percentage = obt / total * 100
document.write('Total Marks: ' + total + '<br>')
document.write('Obtained Marks: ' + obt + '<br>')
document.write('Percentage: ' + percentage + '%' + '<br>')

// Task # 9

var usd = 104.80
var sary = 28
var usquan = parseInt(prompt('Enter US Dollar Quantity'))
var syquan = parseInt(prompt('Enter Saudi Riyal Quantity'))
var totalus = usd * usquan
var totalsy = sary * syquan
var cost = totalus + totalsy
document.write('Total Currency in PKR: ' + cost)


// Task # 1
0
var num = 5;
num = (((num + 5) * 10) / 2);
document.write("<h3>" + "Arithmetic Operation in single statement" + "</h3>");
document.write("Output: " + num);


// Task # 1
1
var current = parseInt(prompt('Enter Current Year'))
var birth = parseInt(prompt('Enter your Birth Year'))
var total = current - birth
document.write('Current Year: ' + current + '<br>')
document.write('Birth Year: ' + birth + '<br>')
document.write('Your Age: ' + total)



// Task # 1
2
var pie = 3.142
var r = parseInt(prompt('Enter Radius'))
var circum = 2 * pie * r
var area = pie * r * r

document.write('Radius of a Circle: ' + r + '<br>')
document.write('The Circumference is: ' + circum + '<br>')
document.write('The area is: ' + area)

// Task # 1
3
var favsnack = prompt('Enter your Favourite Snack')
var curage = parseInt(prompt('Enter your Current Age'))
var maxage = parseInt(prompt('Enter Maximum Age'))
var amountsnack = parseInt(prompt('Enter Amount of Snack Per Day'))

var total = (maxage - curage) * 3
document.write('Favourite Snack: ' + favsnack + '<br>')
document.write('Current Age: ' + curage + '<br>')
document.write('Maximum Age: ' + maxage + '<br>')
document.write('Amount of Snacks per day: ' + amountsnack + '<br>')
document.write('You will need ' + total + ' to last you until the ripe old age of ' + maxage)